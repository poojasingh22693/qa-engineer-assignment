# Selenium-Cucumber-TestNG-Maven
Uploading automation testing framework built using Selenium-Cucumber-TestNG-Maven


About:
------
This project repository is for the article published on Medium platform.

https://medium.com/@Raghwendra.sonu/web-automation-with-selenium-cucumber-maven-and-testng-using-page-object-model-in-java-f93da15be06e

In this project repository, we are designing a Web Automation framework with Selenium, Cucumber, Maven, and TestNG using Page Object Model in Java.

For details, you can have a look at my above published article. Let me know if this was helpful. If you ever need my help, you can contact me through my LinkedIn Profile.
https://au.linkedin.com/in/raghwendra-sonu
