package runner;

import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.testng.annotations.DataProvider;

public abstract class AbstractTestNGCucumberParallelTests extends AbstractTestNGCucumberTests {

	@Override
	@DataProvider(parallel = false)
	public Object[][] scenarios() {
		return super.scenarios();
	}

}